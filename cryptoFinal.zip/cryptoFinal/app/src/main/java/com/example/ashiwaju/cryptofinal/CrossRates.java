package com.example.ashiwaju.cryptofinal;

class CrossRates{
    private String moneyV;
    private double btcRateV, ethRateV;

    CrossRates(String moneyV, double btcRateV, double ethRateV) {
        this.moneyV = moneyV;
        this.btcRateV = btcRateV;
        this.ethRateV = ethRateV;
    }

    public String getMoneyV() {return moneyV; }
    public double getBtcRate() {
        return btcRateV;
    }
    public double getEthRate() {
        return ethRateV;
    }
}
