package com.example.ashiwaju.cryptofinal;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import static com.example.ashiwaju.cryptofinal.R.id.money;

public class MainActivity extends AppCompatActivity {

    private String TAG = MainActivity.class.getSimpleName();

    private ProgressDialog pDialog;
    private ListView lv;

    public static final String KEY_MONEY="money";
    public static final String KEY_BTC="btcRate";
    public static final String KEY_ETH = "ethRate";

    //URL of the Json
    private static String url = "https://min-api.cryptocompare.com/data/pricemulti?fsyms=BTC,ETH&tsyms=NGN,USD,EUR,JPY,GBP,AUD,CAD,CHF,CNY,KES,GHS,UGX,ZAR,XAF,NZD,MYR,BND,GEL,RUB,INR";
    ArrayList<HashMap<String, String>> rateLists;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rateLists = new ArrayList<>();

        lv = (ListView) findViewById(R.id.listView);

        new GetRates().execute();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }



    private class GetRates extends AsyncTask<Void, Void, Void>{

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //show loading dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("loading...");
            pDialog.setCancelable(false);
            pDialog.show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            HttpHandler sh = new HttpHandler();

            String jsonStr = sh.makeServiceCall(url);
            ArrayList<String> BTC = new ArrayList<String>();
            ArrayList<String> ETH = new ArrayList<String>();
            ArrayList<String> Curr = new ArrayList<String>();
            Log.e(TAG, "Response from JSON: " + jsonStr);
            String cVal = "";
            if(jsonStr != null){
                try{
                    JSONObject jObj = new JSONObject(jsonStr);
                    Iterator<String> keysIterator1 = jObj.keys();
                    while (keysIterator1.hasNext())
                    {
                        String jsonArr="";
                        String mYKey = (String)keysIterator1.next();
                        JSONObject preferencesJSON = jObj.getJSONObject(mYKey);
                        Iterator<String> keysIterator = preferencesJSON.keys();
                        while (keysIterator.hasNext())
                        {
                            String keyStr = (String)keysIterator.next();
                            String valueStr = preferencesJSON.getString(keyStr);
                            jsonArr += keyStr + ":" + valueStr + "\n";
                            if(mYKey.equalsIgnoreCase("BTC")) {
                                BTC.add(valueStr);
                                Curr.add(keyStr);
                            }
                            if(mYKey.equalsIgnoreCase("BTC")) {
                                ETH.add(valueStr);
                            }
                        }
                        Log.e(TAG, "Response : " + mYKey + "=>" + jsonArr);
                    }

                    for (int i = 0; i < Curr.size(); i++) {
                        String name = Curr.get(i);
                        String strBTC = BTC.get(i); //BTC
                        String strETH = ETH.get(i); //ETH

                        // tmp hash map for single contact
                        HashMap<String, String> rateGet = new HashMap<>();

                        // adding each child node to HashMap key => value
                        rateGet.put("name", name);
                        rateGet.put("strBTC", strBTC);
                        rateGet.put("strETH", strETH);

                        // adding contact to contact list
                        rateLists.add(rateGet);
                    }


                }catch (final JSONException e){
                    Log.e(TAG, "JSON Parsing error: " + e.getMessage());

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this,
                                    "JSON Parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }else{
                Log.e(TAG, "Couldn't get json from server.");

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,
                                "Couldn't get json from server.",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            //Dismiss the dialog
            if(pDialog.isShowing()){
                pDialog.dismiss();
            }

            //updating json data to listview
            final ListAdapter adapter = new SimpleAdapter(
                    MainActivity.this,rateLists,
                    R.layout.list_item, new String[]{"name","strBTC", "strETH"},
                    new int[]{money,R.id.btcRate, R.id.ethRate});
            lv.setAdapter(adapter);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long offset) {
                    CrossRates item = (CrossRates) adapter.getItem(position);

                    Intent intent = new Intent(getApplicationContext(), singleConversion.class);
                    intent.putExtra(KEY_MONEY, item.getMoneyV());
                    intent.putExtra(KEY_BTC, item.getBtcRate());
                    intent.putExtra(KEY_ETH, item.getEthRate());

                    startActivity(intent);
                }
            });

        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
