package com.example.ashiwaju.cryptofinal;

public interface Constants {
    String EXTRA_CURRENCY = "extra currency";
    String EXTRA_BTC_RATE = "extra btc";
    String EXTRA_ETH_RATE = "extra eth";

    String INVALID_CONVERSION = "Invalid conversion value provided";
}